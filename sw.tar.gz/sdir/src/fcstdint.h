#ifndef _FONTCONFIG_SRC_FCSTDINT_H
#define _FONTCONFIG_SRC_FCSTDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "fontconfig 2.13.91"
/* generated using gnu compiler gcc (GCC) 9.1.1 20190503 (Red Hat 9.1.1-1) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
